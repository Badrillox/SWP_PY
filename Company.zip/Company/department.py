import enum


class Department(enum.Enum):
    LogisticsTec = 1
    Development = 2
    NotSpecified = 3